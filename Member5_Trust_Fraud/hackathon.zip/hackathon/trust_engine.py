import time
from datetime import datetime

class TrustEngine:

    # caller history and timestamp initialization
    def __init__(self):
        self.caller_history = {}

    def get_current_timestamp(self):
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # trust score calculation
    def trust_score(self, caller_id, call_duration, consent_status):

        score = 100
        flags = []

        # fetch or create caller record
        caller_data = self.caller_history.get(caller_id, {
            "total_calls": 0,
            "last_call_time": None,
            "short_calls": 0
        })

        caller_data["total_calls"] += 1
        current_time = time.time()

        # detect repeat calls
        if caller_data["last_call_time"]:
            time_gap = current_time - caller_data["last_call_time"]

            if time_gap < 600:
                score -= 30
                flags.append("Multiple repeat calls in short time")

        caller_data["last_call_time"] = current_time

        # consent behaviour
        if consent_status == "denied":
            score -= 25
            flags.append("Consent denied")

        # detect suspicious call duration
        if call_duration < 5:
            caller_data["short_calls"] += 1
            score -= 20
            flags.append("Very short / dropped call")

        if caller_data["short_calls"] >= 3:
            score -= 15
            flags.append("Repeated short duration calls")

        # risk level classification
        if score >= 70:
            risk_level = "Trusted"
        elif score >= 40:
            risk_level = "Suspicious"
        else:
            risk_level = "High Risk"

        # store updated history
        self.caller_history[caller_id] = caller_data

        # final result object
        result = {
            "caller_id": caller_id,
            "timestamp": self.get_current_timestamp(),
            "total_calls_made": caller_data["total_calls"],
            "short_calls": caller_data["short_calls"],
            "trust_score": score,
            "risk_level": risk_level,
            "flags_triggered": flags
        }

        self.print_log(result)
        return result

    # logging output
    def print_log(self, result):

        print("\n           Trust Evaluation             ")
        print(f"Caller ID: {result['caller_id']}")
        print(f"Timestamp: {result['timestamp']}")
        print(f"Total Calls: {result['total_calls_made']}")
        print(f"Short Calls: {result['short_calls']}")
        print(f"Trust Score: {result['trust_score']}")
        print(f"Risk Level: {result['risk_level']}")

        if result['flags_triggered']:
            print("\nFlags Triggered:")
            for flag in result['flags_triggered']:
                print(f"- {flag}")
        else:
            print("\nNo suspicious behavior detected")
        print("\n")

if __name__ == "__main__":

    engine = TrustEngine()

    print("\n--- Simulating Caller 1 ---")
    engine.trust_score("+91XXXX1111", 2, "granted")
    engine.trust_score("+91XXXX1111", 3, "granted")
    engine.trust_score("+91XXXX1111", 2, "granted")

    print("\n--- Simulating Caller 2 (Consent Denied) ---")
    engine.trust_score("+91YYYY2222", 8, "denied")
