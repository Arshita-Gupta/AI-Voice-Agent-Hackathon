import { handleConsent } from "./consent_guard.js";
import { getAIReply } from "./ai_brain.js";

process.env.OPENAI_KEY = "PASTE_YOUR_OPENAI_KEY_HERE";

const callSid = "TEST_CALL_1";

async function run() {

  console.log("\n--- CALL STARTS ---");

  // Step 1: Call starts (no speech yet)
  let res = handleConsent(callSid, "");
  console.log("AI:", res.text);

  // Step 2: User says NO
  let user = "no";
  res = handleConsent(callSid, user);
  console.log("User:", user);
  console.log("AI:", res.text);

  console.log("\n--- NEW CALL ---");

  const callSid2 = "TEST_CALL_2";

  // Step 3: Start again
  res = handleConsent(callSid2, "");
  console.log("AI:", res.text);

  // Step 4: User says YES
  user = "yes";
  res = handleConsent(callSid2, user);
  console.log("User:", user);
  console.log("AI:", res.text);

  // Step 5: Now real AI starts
  const question = "I did not receive my pension";
  console.log("User:", question);

  const ai = await getAIReply(callSid2, question);
  console.log("AI:", ai);

}

run();
