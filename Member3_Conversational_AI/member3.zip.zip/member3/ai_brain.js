import dotenv from "dotenv";
dotenv.config();  
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});


const conversations = {};

export async function getAIReply(callSid, userText) {

  if (!conversations[callSid]) {
    conversations[callSid] = [
      {
        role: "system",
        content: "You are a polite and helpful government service assistant speaking to citizens over a phone call."
      }
    ];
  }

  conversations[callSid].push({
    role: "user",
    content: userText
  });

  let reply = "Sorry, I could not understand that.";

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: conversations[callSid],
      max_tokens: 150
    });

    reply = response.choices[0].message.content;

    conversations[callSid].push({
      role: "assistant",
      content: reply
    });
  }
  catch (error) {
    reply = "I am facing a technical issue right now. Please try again.";
  }

  return reply;
}
