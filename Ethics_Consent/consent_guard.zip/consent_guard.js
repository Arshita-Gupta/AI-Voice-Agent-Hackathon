import fs from "fs";

const consent = {};

export function handleConsent(callSid, userText) {

  // If consent not taken yet
  if (!consent[callSid]) {

    // First message when call starts
    if (!userText || userText.trim() === "") {
      return {
        text: "Hello. This is an AI system assisting government services. This call may be recorded for safety and fraud prevention. Do you give your consent to continue? Please say Yes or No.",
        hangup: false,
        done: false
      };
    }

    // If user says YES
    if (userText.toLowerCase().includes("yes")) {
      consent[callSid] = true;
      fs.appendFileSync("consent.log", `${callSid}, YES, ${new Date().toISOString()}\n`);

      return {
        text: "Thank you for your consent. You may now ask your question.",
        hangup: false,
        done: true
      };
    }

    // If user says NO or anything else
    fs.appendFileSync("consent.log", `${callSid}, NO, ${new Date().toISOString()}\n`);

    return {
      text: "Without your consent, I must end this call. Goodbye.",
      hangup: true,
      done: false
    };
  }

  // Consent already given
  return {
    done: true
  };
}
