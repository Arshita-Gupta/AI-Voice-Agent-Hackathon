mport whisper
from langdetect import detect

model = whisper.load_model("base")

def speech_to_text(audio_path):
    result = model.transcribe(audio_path)
    text = result["text"].strip()

    # If text is too short, trust Whisper's language detection
    if len(text.split()) < 3:
        language = result.get("language", "en")
    else:
        language = detect(text)

    return text, language


# -------- TESTING --------
if __name__ == "__main__":
    audio_file = "sample.wav"
    text, language = speech_to_text(audio_file)

    print("Text:", text)
    print("Language:", language)
