from stt import speech_to_text
from tts import text_to_speech

def process_audio(audio_path):
    text, language = speech_to_text(audio_path)
    audio_response = text_to_speech(text, language)
    return text, language, audio_response
