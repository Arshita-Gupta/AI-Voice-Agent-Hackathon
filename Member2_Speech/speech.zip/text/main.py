from fastapi import FastAPI, UploadFile
import shutil
from stt import speech_to_text
from tts import text_to_speech

app = FastAPI()

@app.post("/stt")
async def stt_api(file: UploadFile):
    with open("temp.wav", "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    text, language = speech_to_text("temp.wav")
    return {"text": text, "language": language}

@app.post("/tts")
async def tts_api(text: str, language: str):
    audio = text_to_speech(text, language)
    return {"audio_file": audio}
