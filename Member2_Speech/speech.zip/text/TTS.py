from gtts import gTTS

def text_to_speech(text, language):
    tts = gTTS(text=text, lang=language)
    tts.save("reply.mp3")
    return "reply.mp3"


# -------- TESTING --------
if __name__ == "__main__":
    text = "Hello, this is the AI voice agent speaking."
    audio_file = text_to_speech(text, "en")
